import React from 'react';
import './styles.css';

const Header = () => (
  <header className='home-header'>
  
    <h1>
      <span>“</span>Events<span>”</span>
    </h1>
  
  </header>
);

export default Header;